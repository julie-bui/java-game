package game;

import city.cs.engine.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


//class used to change appearance of game on screen
public class GameView extends UserView {
    //variable for backrgound image
    private Image backgroundImage;
    //reference player object
    private Player player;
    private static final Font STATUS_FONT = new Font("Monospaced", Font.PLAIN, 20);
    private String displayLevel = "Level 1";

    private long levelStartTime;
    private int elapsedTime = 0; // in seconds

    private JButton backToMenuButton;

    private JButton saveButton;
    private JButton pauseButton;
    private JButton playButton;

    private Game game;


    //constructor initialises gameview
    public GameView(World world, int width, int height, Player player, Game game) {
        //call constructor UserView to initialise world, width, hieght
        super(world, width, height);
        //assign player reference to player instance variable
        this.player = player;
        this.game = game;
        backgroundImage = new ImageIcon("java-project-2025-julie-bui/data/backgroundNature.jpg").getImage(); // Load background image


        // Create and position the "Back to Menu" button in the top-right corner
        backToMenuButton = new JButton("Menu");
        backToMenuButton.setFont(new Font("Arial", Font.BOLD, 14));
        backToMenuButton.setBounds(660, 10, 120, 30); // Set position to the top-right corner
        backToMenuButton.setFocusable(false);
        backToMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                backToMenu();  // Handle the back to menu action
            }
        });
        this.setLayout(null); // Use absolute positioning for the button
        this.add(backToMenuButton);

        // Save Button
        saveButton = new JButton("Save Game");
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));
        saveButton.setBounds(660, 40, 120, 30); // top-left corner
        saveButton.setFocusable(false);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.saveGame(); // call save game
            }
        });
        this.add(saveButton);

        // Pause Button
        pauseButton = new JButton("Pause Game");
        pauseButton.setFont(new Font("Arial", Font.BOLD, 14));
        pauseButton.setBounds(660, 70, 120, 30); // below Save button
        pauseButton.setFocusable(false);
        pauseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.pauseGame(); // call load game
            }
        });
        this.add(pauseButton);

        // Play Button
        playButton = new JButton("Play Game");
        playButton.setFont(new Font("Arial", Font.BOLD, 14));
        playButton.setBounds(660, 100, 120, 30);
        playButton.setFocusable(false);
        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                game.resumeGame(); // call load game
            }
        });
        this.add(playButton);
    }

    private void backToMenu() {
        // Close the current game window and show the menu
        JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
        topFrame.dispose();  // Close the current game window
        new Game();  // Call the Game class to start the menu again
    }



    public void setPlayer(Player player) {
        this.player = player;
    }


    public void setBackgroundImage(String imagePath) {
        backgroundImage = new ImageIcon(imagePath).getImage();
        repaint();  // To immediately reflect the new background
    }

    public void setDisplayLevel(String displayLevelNum) {
        this.displayLevel = displayLevelNum;
    }

    public void setLevelStartTime(long startTime) {
        this.levelStartTime = startTime;
    }

    public void updateElapsedTime() {
        this.elapsedTime = (int)((System.currentTimeMillis() - levelStartTime) / 1000);
        repaint();
    }

    public int getElapsedTime() {
        return elapsedTime;
    }

    public void setElapsedTime(int elapsedTime) {
        this.elapsedTime = elapsedTime;
        repaint(); // Redraw the view with updated elapsed time
    }

    public void resetElapsedTime() {
        this.elapsedTime = 0;
        repaint();
    }


    //draws background image by overriding painBackground method
    @Override
    protected void paintBackground(Graphics2D g) {
        //background image fills entire view
        g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this); // Draw background
    }

    //shows carrots collected
    @Override
    protected void paintForeground(Graphics2D g) {
        int carrots = player.getCarrots();
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        //g.setFont(STATUS_FONT);
        g.drawString("Carrots collected: " + carrots, 30, 40);
        g.drawString("Time: " + elapsedTime + "s", 30, 70);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Draw level name in center
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.setColor(Color.WHITE);
        FontMetrics fm = g.getFontMetrics();
        int textWidth = fm.stringWidth(displayLevel);
        g.drawString(displayLevel, (getWidth() - textWidth) / 2, 40);
    }

}