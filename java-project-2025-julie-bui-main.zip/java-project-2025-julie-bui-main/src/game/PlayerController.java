package game;

import city.cs.engine.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * PlayerController class listens for key events and translates into player actions
 * e.g. moving left, right
 */
//class deals with player movements depending on keys pressed
public class PlayerController extends KeyAdapter {
    //reference to player
    private Player player;
    //constructor assign given player instance to controller
    public PlayerController(Player player) {
        this.player = player;
    }

    /**
     *
     * @param e processes key event and movement
     *          keys supported include arrow keys, WASD for movement, spacebar, up arrow for jump
     */
    //called when key pressed
    @Override
    public void keyPressed(KeyEvent e) {
        //get key code of pressed key
        int keyCode = e.getKeyCode();
        // Handle left and right movement (WASD or Arrow Keys)
        if (keyCode == KeyEvent.VK_LEFT || keyCode == KeyEvent.VK_A) {
            player.moveLeft();
        } else if (keyCode == KeyEvent.VK_RIGHT || keyCode == KeyEvent.VK_D) {
            player.moveRight();
        }

        // Handle Jumping (Space Bar or Up Arrow Key)
        if ((keyCode == KeyEvent.VK_SPACE || keyCode == KeyEvent.VK_UP || keyCode == KeyEvent.VK_W)) {
            player.jump();
        }

        // move down
        if ((keyCode == KeyEvent.VK_DOWN|| keyCode == KeyEvent.VK_S)) {
            player.movePlayerDown();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int keyCode = e.getKeyCode();

        // Stop the player from moving when the key is released
        if (keyCode == KeyEvent.VK_LEFT || keyCode == KeyEvent.VK_A) {
            player.stopMovingLeft();
        } else if (keyCode == KeyEvent.VK_RIGHT || keyCode == KeyEvent.VK_D) {
            player.stopMovingRight();
        }
    }
}

