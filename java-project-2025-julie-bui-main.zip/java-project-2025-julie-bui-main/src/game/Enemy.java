package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

import city.cs.engine.StepEvent;
import city.cs.engine.StepListener;

/**
 * enemy class is fox character in game that moves and chase player
 * enemy's behaviour becomes more aggressive as levels increase, chasing the player in level 2 and 3
 * uses steplistener to handle movement based on game's physics
 */
public class Enemy extends Walker implements StepListener{
    private static final Shape playerShape = new BoxShape(1, 2);
    //images for right and left side
    private static final BodyImage rightImage = new BodyImage("java-project-2025-julie-bui/data/foxRight.gif", 4);
    private static final BodyImage leftImage = new BodyImage("java-project-2025-julie-bui/data/foxLeft.gif", 4);
    private AttachedImage currentImage;
    private boolean facingRight = true; // Track the player's direction
    //defines boundaries
    private float leftBoundary, rightBoundary;

    private GameLevel currentLevel;
    private Player player;

    /**
     *
     * @param world game world where enemy places
     * @param left left boundary
     * @param right right boundary
     */
    //constructor initialise enemy with movement boundaries
    public Enemy(World world, float left, float right) {
        //call superclass walker with defined shape
        super(world, playerShape);
        //sets boundaries
        this.leftBoundary = left;
        this.rightBoundary = right;

        //enemy has right image at first
        currentImage = new AttachedImage(this, rightImage, 1, 0, new Vec2(0, 0));

        //add instance as stepListener t execute actions
        world.addStepListener(this);
    }

    /**
     *
     * @param movingRight if true, enemy faces right otherwise left
     */
    //set direction and change image accordingly
    public void setDirection(boolean movingRight) {
        //if new direction same as current
        if (movingRight == facingRight) {
            return; // Exit early if direction hasn’t changed
        }//update direction
        facingRight = movingRight; // Update direction

        // Remove the current image before adding the new one to prevent duplicates
        if (currentImage != null) {
            this.removeAttachedImage(currentImage);
        }
        //add new image depending on direction enemy facing
        currentImage = new AttachedImage(this, facingRight ? rightImage : leftImage, 1, 0, new Vec2(0, 0));
    }

    /**
     *
     * @return true if enemy facing right, otherwise false
     */
    //method checks if enemy facing right
    public boolean isFacingRight() {
        //returns true if facing right, false facing left
        return facingRight;
    }

    /**
     * sets current level for enemy used to decide behaviour of enemy
     * @param level game level that it set
     */
    public void setLevel(GameLevel level) {
        this.currentLevel = level;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    /**
     * method called before each physics step to update enemy's behvaiour
     * enemy moves based on current level
     * @param stepEvent step event that is triggered each physics step
     */
    @Override
    public void preStep(StepEvent stepEvent) {
        Vec2 pos = this.getPosition();  // Get the current position of the enemy

        // If it's Level 2 or Level 3, the fox will chase the player
        if (currentLevel instanceof LevelTwo || currentLevel instanceof LevelThree) {
            if (player != null) {
                Vec2 playerPos = player.getPosition();
                float dx = playerPos.x - pos.x;
                float dy = playerPos.y - pos.y;
                float distance = (float)Math.sqrt(dx * dx + dy * dy);

                // In Level 3, the fox chases the bunny more aggressively
                if (currentLevel instanceof LevelThree) {
                    // Increase speed and start chasing from a greater distance in Level 3
                    //12
                    if (distance < 12) {  // Start chasing from a further distance
                        //4
                        setLinearVelocity(playerPos.sub(pos).mul(4));  // Move faster in Level 3
                    } else {
                        // Boundary-based patrol movement
                        if (pos.x <= leftBoundary) {
                            startWalking(7);  // Move faster on the left side
                            setDirection(true); // Face right
                        } else if (pos.x >= rightBoundary) {
                            startWalking(-7); // Move faster on the right side
                            setDirection(false); // Face left
                        }
                    }
                } else {
                    // Default chasing behavior in Level 2
                    //10
                    if (distance < 10) {
                        //2
                        setLinearVelocity(playerPos.sub(pos).mul(2));  // Normal chasing speed in Level 2
                    } else {
                        // Boundary-based patrol movement for Level 2
                        if (pos.x <= leftBoundary) {
                            startWalking(5);  // Move to the right
                            setDirection(true); // Face right
                        } else if (pos.x >= rightBoundary) {
                            startWalking(-5); // Move to the left
                            setDirection(false); // Face left
                        }
                    }
                }
            }
        } else {
            // Default behavior for Level 1 (patrol even if not chasing the bunny)
            if (pos.x <= leftBoundary) {
                startWalking(5);  // Move to the right
                setDirection(true); // Face right
            } else if (pos.x >= rightBoundary) {
                startWalking(-5); // Move to the left
                setDirection(false); // Face left
            }
        }
    }



    @Override
    public void postStep(StepEvent stepEvent) {
        //required to complete the StepListener interface.
    }
}




