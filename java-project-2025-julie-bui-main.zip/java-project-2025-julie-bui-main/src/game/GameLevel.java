package game;

import city.cs.engine.*;

public abstract class GameLevel extends World {
    protected Player player;
    protected Enemy enemy;

    public Player getPlayer() {
        return player;
    }

    public Enemy getEnemy() {
        return enemy;
    }

    /** Populate the world with objects like platforms, carrots, enemies, etc. */
    public abstract void populate(Game game);

    /** Total number of carrots in this level */
    public abstract int getNumCarrots();

    /** Level background image path different backgrounds */
    public abstract String getBackground();

    /** player met the win condition */
    public abstract boolean isComplete();

    public abstract String getName();
}
