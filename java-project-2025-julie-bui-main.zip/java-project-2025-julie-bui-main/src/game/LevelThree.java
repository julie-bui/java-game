package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import java.awt.*;

/**
 * represents third level in game
 * extends game level class and populates level with platforms
 * handles collision with player and fox and carrot objects
 */
public class LevelThree extends GameLevel {

    private Game game;
    private int numCarrots;

    @Override
    public void populate(Game game) {

        this.game = game;

        //2. populate it with bodies (ex: platforms, collectibles, characters)
        //creates ground that's static body, sets width, height, position
        Shape shape = new BoxShape(20, 1f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -14f));
        ground.setFillColor(new Color(120, 140, 80));

        //platform 1
        Shape platformShape = new BoxShape(1f, 0.5f);
        StaticBody platform1 = new StaticBody(this, platformShape);
        platform1.setPosition(new Vec2(-8, 6));
        platform1.setFillColor(new Color(120, 140, 80));

        //platform 2
        Shape platformShape2 = new BoxShape(1f, 0.1f);
        StaticBody platform2 = new StaticBody(this, platformShape);
        platform2.setPosition(new Vec2(12, -3f));
        platform2.setFillColor(new Color(120, 140, 80));

        //platform 3
        Shape platformShape3 = new BoxShape(1, 0.5f);
        StaticBody platform3 = new StaticBody(this, platformShape);
        platform3.setPosition(new Vec2(15, 3f));
        platform3.setFillColor(new Color(120, 140, 80));

        //platform 4
        Shape platformShape4 = new BoxShape(1, 0.5f);
        StaticBody platform4 = new StaticBody(this, platformShape);
        platform4.setPosition(new Vec2(0, 2f));
        platform4.setFillColor(new Color(120, 140, 80));

        //platform 5
        Shape platformShape5 = new BoxShape(1, 0.5f);
        StaticBody platform5 = new StaticBody(this, platformShape);
        platform5.setPosition(new Vec2(-12, 0f));
        platform5.setFillColor(new Color(120, 140, 80));

        //platform 6
        Shape platformShape6 = new BoxShape(1, 0.5f);
        StaticBody platform6 = new StaticBody(this, platformShape);
        platform6.setPosition(new Vec2(8, 8f));
        platform6.setFillColor(new Color(120, 140, 80));

        //platform 7
        Shape platformShape7 = new BoxShape(1, 0.5f);
        StaticBody platform7 = new StaticBody(this, platformShape);
        platform7.setPosition(new Vec2(-1, 9f));
        platform7.setFillColor(new Color(120, 140, 80));

        //platform 8
        Shape platformShape8 = new BoxShape(1, 0.5f);
        StaticBody platform8 = new StaticBody(this, platformShape);
        platform8.setPosition(new Vec2(-4, -3f));
        platform8.setFillColor(new Color(120, 140, 80));

        //creates the bunny character, sets position
        player = new Player(this);
        player.setPosition(new Vec2(0, -9));
        //adds method collision listener with class
        player.addCollisionListener(new CarrotCollision(player, game));
        player.addCollisionListener(new PlayerCollision(player, game));

        //creates enemy fox, sets bounds and position
        enemy = new Enemy(this, -20, 20);
        enemy.setPosition(new Vec2(20, -9));
        // Set the current level to LevelThree
        enemy.setLevel(this);
        // Set player reference for the enemy
        enemy.setPlayer(player);

        //number of carrots
        numCarrots = 8;

        //creates carrots with positions
        Carrot carrot1 = new Carrot(this);
        carrot1.setPosition(new Vec2(-8, 9));

        Carrot carrot2 = new Carrot(this);
        carrot2.setPosition(new Vec2(0, 5));

        Carrot carrot3 = new Carrot(this);
        carrot3.setPosition(new Vec2(12, 0));

        Carrot carrot4 = new Carrot(this);
        carrot4.setPosition(new Vec2(15, 8));

        Carrot carrot5 = new Carrot(this);
        carrot5.setPosition(new Vec2(-12, 2));

        Carrot carrot6 = new Carrot(this);
        carrot6.setPosition(new Vec2(8, 10));

        Carrot carrot7 = new Carrot(this);
        carrot7.setPosition(new Vec2(-1, 10));

        Carrot carrot8 = new Carrot(this);
        carrot8.setPosition(new Vec2(-4, 0));
    }



    @Override
    public int getNumCarrots() {
        return numCarrots;
    }

    @Override
    public boolean isComplete() {
        return getPlayer().getCarrots() >= numCarrots;
    }

    @Override
    public String getBackground() {
        return "java-project-2025-julie-bui/data/background3.jpg";
    }

    @Override
    public String getName() {
        return "Level 3";
    }


}
