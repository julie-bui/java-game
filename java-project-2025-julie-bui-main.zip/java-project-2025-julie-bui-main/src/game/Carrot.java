package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;


//class is a collectible extending dynamicbody
public class Carrot extends DynamicBody implements StepListener{
    //defines shape of carrot
    private static final Shape carrotShape = new CircleShape(0.5f);
    //image of carrot
    private static final BodyImage carrotImage = new BodyImage("java-project-2025-julie-bui/data/carrot.png", 3);
    //constructor creates carrot object
    public Carrot(World world) {
        //call superclass constructor to create body with shape
        super(world, carrotShape);
        //add image to body
        addImage(carrotImage);
        world.addStepListener(this);
    }
    @Override
    public void preStep(StepEvent e) {
        // Get current position
        float x = this.getPosition().x;
        float y = this.getPosition().y;

        // Define screen boundaries (adjust if needed!)
        float leftBound = -19;
        float rightBound = 19;
        float bottomBound = -20;
        float topBound = 14;

        // Clamp carrot inside the screen
        if (x < leftBound) {
            this.setPosition(new Vec2(leftBound, y));
        } else if (x > rightBound) {
            this.setPosition(new Vec2(rightBound, y));
        }

        if (y < bottomBound) {
            this.setPosition(new Vec2(x, bottomBound));
        } else if (y > topBound) {
            this.setPosition(new Vec2(x, topBound));
        }
    }

    @Override
    public void postStep(StepEvent e) {
        // Nothing needed after step
    }
}








