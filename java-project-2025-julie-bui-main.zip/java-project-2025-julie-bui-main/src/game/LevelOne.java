package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import java.awt.*;

public class LevelOne extends GameLevel {
    private int numCarrots;

    @Override
    public void populate(Game game) {
        //2. populate it with bodies (ex: platforms, collectibles, characters)
        //creates ground that's static body, sets width, height, position
        Shape shape = new BoxShape(20, 1f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -14f));
        ground.setFillColor(new Color(150, 180, 160));

        //platform 1
        Shape platformShape = new BoxShape(3.5f, 0.5f);
        StaticBody platform1 = new StaticBody(this, platformShape);
        platform1.setPosition(new Vec2(-8, 6));
        platform1.setFillColor(new Color(150, 180, 160));

        //platform 2
        Shape platformShape2 = new BoxShape(3.5f, 0.1f);
        StaticBody platform2 = new StaticBody(this, platformShape);
        platform2.setPosition(new Vec2(12, -3f));
        platform2.setFillColor(new Color(150, 180, 160));

        //platform 3
        Shape platformShape3= new BoxShape(1, 0.5f);
        StaticBody platform3 = new StaticBody(this, platformShape);
        platform3.setPosition(new Vec2(15, 3f));
        platform3.setFillColor(new Color(150, 180, 160));

        //platform 4
        Shape platformShape4= new BoxShape(1, 0.5f);
        StaticBody platform4 = new StaticBody(this, platformShape);
        platform4.setPosition(new Vec2(0, 2f));
        platform4.setFillColor(new Color(150, 180, 160));

        //creates the bunny character, sets position
        player = new Player(this);
        player.setPosition(new Vec2(0, -9));
        //adds method collision listener with class
        player.addCollisionListener(new CarrotCollision(player, game));
        player.addCollisionListener(new PlayerCollision(player, game));

        //creates enemy fox, sets bounds and position
        enemy = new Enemy(this, -20, 20);
        enemy.setPosition(new Vec2(20, -9));

        //number of carrots
        numCarrots = 4;

        //creates carrots with positions
        Carrot carrot1 = new Carrot(this);
        carrot1.setPosition(new Vec2(-8, 9));

        Carrot carrot2 = new Carrot(this);
        carrot2.setPosition(new Vec2(0, 5));

        Carrot carrot3 = new Carrot(this);
        carrot3.setPosition(new Vec2(10, 0));

        Carrot carrot4 = new Carrot(this);
        carrot4.setPosition(new Vec2(15, 5));

    }

    @Override
    public int getNumCarrots() {
        return numCarrots;
    }

    @Override
    public boolean isComplete() {
        // win as soon as the player’s carrot count reaches the level’s total
        return getPlayer().getCarrots() >= numCarrots;
    }


    @Override
    public String getBackground() {
        return "java-project-2025-julie-bui/data/backgroundNature.jpg";
        //return "java-project-2025-julie-bui/data/backgroundSunset.png";
    }

    @Override
    public String getName() {
        return "Level 1";
    }
}