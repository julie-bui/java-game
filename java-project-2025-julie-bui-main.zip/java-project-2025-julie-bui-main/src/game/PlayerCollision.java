package game;

import city.cs.engine.*;

//class implements collisionlistener interface to detect collisions
public class PlayerCollision implements CollisionListener {
    //decclare variables for reference to player, game object
    private Player player;
    private Game game;

    //constructor initialise playercollions object with player, game instances
    public PlayerCollision(Player player, Game game) {
        //player, game reference
        this.player = player;
        this.game = game;
    }

    //checks if player has collided with enemy, if so remove player
    @Override
    public void collide(CollisionEvent e) {

        //gets the body player has collided with
        Body other = e.getOtherBody();
        //if other body is enemy, destroy the player
        if (other instanceof Enemy && e.getReportingBody() == player) {
            player.destroy(); //remove player
            game.playCollisionSound();
            game.displayGameOver(); //call displayGameOver from Game class
        }
    }
}

