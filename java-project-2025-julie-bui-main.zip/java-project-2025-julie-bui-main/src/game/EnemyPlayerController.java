package game;

import city.cs.engine.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import org.jbox2d.common.Vec2;

/**
 * class handles movement and actions of enemy character fox
 * uses keyAdapter to simplify key event handling
 * listens for key events and moves enemy left right or jumping based on keys pressed by user
 */
public class EnemyPlayerController extends KeyAdapter {
    //declare enemy object
    private Enemy enemy;

    //constructor inistialises EnemyPlayerController with enemy object
    public EnemyPlayerController(Enemy enemy) {
        this.enemy = enemy;
    }

    /**
     * called when key pressed, moves enemy based on keys pressed
     * @param e the event to be processed
     */

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();

        //move left using A or left arrow
        if (keyCode == KeyEvent.VK_A || keyCode == KeyEvent.VK_LEFT) {
            enemy.setDirection(false);
            //set linear velocity to move left while vertical velocity same
            enemy.setLinearVelocity(new Vec2(-10, enemy.getLinearVelocity().y));
        }
        //move right using D or right arrow
        else if (keyCode == KeyEvent.VK_D || keyCode == KeyEvent.VK_RIGHT) {
            enemy.setDirection(true);
            enemy.setLinearVelocity(new Vec2(10, enemy.getLinearVelocity().y)); // Move right
        }
        //jump using w or up arrow
        else if (keyCode == KeyEvent.VK_W || keyCode == KeyEvent.VK_UP) {
            //jump strength
            enemy.jump(10);
        }
    }

    /**
     * stops enemy from moving used when key released
     * @param e the event to be processed
     */
    @Override
    public void keyReleased(KeyEvent e) {
        //stops enemy from moving when a key isn't pressed
        enemy.setLinearVelocity(new Vec2(0, enemy.getLinearVelocity().y));
    }
}
