package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;
import javax.swing.JFrame;
import java.awt.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.SwingConstants;


import javax.swing.*;
import javax.sound.sampled.*;
import java.io.IOException;

import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


/**
 main class to run game
 */
public class Game {
    private GameView view;
    //declare player, enemy as instance variable
    private Player player;
    private Enemy enemy;
    //set number of carrots and tracks carrots collected
    private int numCarrots;
    private int collectedCarrots = 0;
    private int sumCarrotsCollected = 0;
    //game level
    private GameLevel currentLevel;
    //private int levelNumber = 1;

    private SoundClip backgroundMusic;
    private SoundClip collectSound;
    private SoundClip collisionSound;
    private SoundClip victorySound;
    private SoundClip winSound;

    private JFrame menuFrame;
    private JDialog menuDialog;
    private JFrame gameFrame;

    private Timer timer;
    private javax.swing.Timer gameTimer;
    private long pauseTime = 0;

    private boolean isGameRunning = false;
    private boolean isInMenu = true;


    /** Initialise a new Game. */
    public Game() {

        // Initialize the game frame here
        gameFrame = new JFrame("Game");
        gameFrame.setSize(800, 600);  // Set an appropriate size for your game window
        gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gameFrame.setLocationRelativeTo(null);  // Position the frame in the center of the screen
        currentLevel = new LevelOne();
        displayMenu();
    }
    public boolean isInMenu() {
        return isInMenu;
    }
    // Check if the game is running
    public boolean isGameRunning() {
        return isGameRunning;
    }
    //displays menu of game displaying options to start game, quit or choose levels
    private void displayMenu() {
        pauseGame();

        isInMenu = true;

        gameFrame.setVisible(false);
        menuDialog= new JDialog(gameFrame, "Main Menu", true); // true makes it modal
        menuDialog.setSize(400, 300);
        menuDialog.setLocationRelativeTo(gameFrame); // Position relative to the game frame
        menuDialog.setLayout(new BorderLayout());

        // Title label
        JLabel titleLabel = new JLabel("Welcome to the Game", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Monospaced", Font.BOLD, 24));
        //menuFrame.add(titleLabel, BorderLayout.NORTH);
        menuDialog.add(titleLabel, BorderLayout.NORTH);

        // Buttons panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(3, 1));

        // Start Game Button
        JButton startButton = new JButton("Start Game");
        startButton.addActionListener(e -> startGame());
        buttonsPanel.add(startButton);

        // Select Level Button
        JButton selectLevelButton = new JButton("Select Level");
        selectLevelButton.addActionListener(e -> selectLevel());
        buttonsPanel.add(selectLevelButton);

        // Quit Button
        JButton quitButton = new JButton("Quit");
        quitButton.addActionListener(e -> System.exit(0));
        buttonsPanel.add(quitButton);

        menuDialog.add(buttonsPanel, BorderLayout.CENTER);
        menuDialog.setVisible(true);

    }

    /**
     * displays options of all levels where user is able to decide level
     * and call the corresponding one
     */
    private void selectLevel() {
        String[] levels = {"Level 1", "Level 2", "Level 3"};
        String selectedLevel = (String) JOptionPane.showInputDialog(null,
                "Select Level",
                "Level Selection",
                JOptionPane.PLAIN_MESSAGE,
                null,
                levels,
                levels[0]);

        if (selectedLevel != null) {
            switch (selectedLevel) {
                case "Level 1":
                    currentLevel = new LevelOne();
                    break;
                case "Level 2":
                    currentLevel = new LevelTwo();
                    break;
                case "Level 3":
                    currentLevel = new LevelThree();
                    break;
            }
            startGame();
        }

    }

    /**
     * starts game from level 1
     * sets up view, sound, input handling for current level
     */
    private void startGame() {
        isInMenu = false;
        menuDialog.setVisible(false);
        if (currentLevel == null) {
            currentLevel = new LevelOne();
        }
        currentLevel.populate(this);

        player = currentLevel.getPlayer();
        
        numCarrots = currentLevel.getNumCarrots();

        // Create the game view
        view = new GameView(currentLevel, 800, 600, player, this);
        view.setDisplayLevel(currentLevel instanceof LevelOne ? "Level 1" :
                currentLevel instanceof LevelTwo ? "Level 2" : "Level 3");
        view.addKeyListener(new PlayerController(player));
        view.setFocusable(true);
        view.requestFocus();

        //set background for selected level
        String backgroundPath = currentLevel.getBackground();

        if (currentLevel instanceof LevelOne) {
            view.setBackgroundImage("java-project-2025-julie-bui/data/backgroundNature.jpg");
        } else if (currentLevel instanceof LevelTwo) {
            view.setBackgroundImage("java-project-2025-julie-bui/data/backgroundSunset.png");
        } else if (currentLevel instanceof LevelThree) {
            view.setBackgroundImage("java-project-2025-julie-bui/data/background3.jpg");
        }

        // Load sounds
        try {
            backgroundMusic = new SoundClip("java-project-2025-julie-bui/data/gametheme.wav");
            backgroundMusic.loop();
            collectSound = new SoundClip("java-project-2025-julie-bui/data/gamebonus.wav");
            victorySound = new SoundClip("java-project-2025-julie-bui/data/victory.wav");
            winSound = new SoundClip("java-project-2025-julie-bui/data/winSound.wav");
            collisionSound = new SoundClip("java-project-2025-julie-bui/data/gameover.wav");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println("Error loading sound: " + e);
        }
        // Add the view to the game frame and make the frame visible
        gameFrame.setContentPane(view);
        gameFrame.setVisible(true);  // Make the game window visible

        currentLevel.start(); // Start the level

        view.setLevelStartTime(System.currentTimeMillis());
        gameTimer = new javax.swing.Timer(1000, e -> view.updateElapsedTime());
        view.resetElapsedTime();
        gameTimer.start();

        isGameRunning = true;

    }

    // Pause the game (to be called when menu is opened)
    public void pauseGame() {
        if (currentLevel != null) {
            currentLevel.stop();  // Call stop() on the current level to halt it
        }
        if (gameTimer != null) {
            gameTimer.stop();  // Stop the game timer when paused
        }
        pauseTime = System.currentTimeMillis();
        isGameRunning = false;  // Mark the game as paused

    }


    // Resume the game (to be called when user starts the game again after menu)
    public void resumeGame() {
        if (!isGameRunning) {
            if (currentLevel != null) {
                currentLevel.start();
            }
        }
        if (gameTimer != null) {
            gameTimer.start();
        }
        isGameRunning = true;
    }


    // Method to play collision sound (e.g., when player hits an enemy)
    public void playCollisionSound() {
        if (collisionSound != null) {
            collisionSound.play();
        }
    }


    /**
     * method to update number of carrots
     * checks if the number of carrots user collects is equal to total carrots,
     * if so call method to display user wins
     */
    public void carrotCollected() {
        if (collectSound != null) {
            collectSound.play();
        }
        collectedCarrots++;
        sumCarrotsCollected++;

        // Check if player collected all carrots for the current level
        if (collectedCarrots >= currentLevel.getNumCarrots()) {
            transitionToNextLevel();
        }
    }

    //method to set up view, sounds of level 2
    public void goToLevelTwo() {
        // Stop the current level
        currentLevel.stop();

        // Create and populate LevelTwo
        currentLevel = new LevelTwo();
        currentLevel.populate(this);
        view.setDisplayLevel("Level 2");

        // reset counters
        numCarrots = currentLevel.getNumCarrots();
        collectedCarrots = 0;

        player = currentLevel.getPlayer();

        // tell the view about the new world, background, and player
        view.setWorld(currentLevel);
        //view.setLevel(currentLevel, currentLevel.getBackground());
        view.setPlayer(player);
        view.addKeyListener(new PlayerController(player));

        // Set the background image for the new level
        String backgroundPath = currentLevel.getBackground();
        view.setBackgroundImage(backgroundPath);

        //Reset the stopwatch
        view.setLevelStartTime(System.currentTimeMillis());
        view.resetElapsedTime();

        currentLevel.start();
    }
    //method to set up view, sounds of level 3
    public void goToLevelThree() {
        currentLevel.stop();

        currentLevel = new LevelThree();
        currentLevel.populate(this);
        view.setDisplayLevel("Level 3");

        numCarrots = currentLevel.getNumCarrots();
        collectedCarrots = 0;

        player = currentLevel.getPlayer();
        view.setWorld(currentLevel);
        view.setPlayer(player);
        view.addKeyListener(new PlayerController(player));

        String backgroundPath = currentLevel.getBackground();
        view.setBackgroundImage(backgroundPath);

        //Reset the stopwatch
        view.setLevelStartTime(System.currentTimeMillis());
        view.resetElapsedTime();

        currentLevel.start();
    }

    /**
     * if user wins, message popup displays user has won and has completed all levels
     * displays time taken and number of carrots collected
     */
    //method to display user wins
    private void displayWinMessage() {
        if (currentLevel != null) {
            currentLevel.stop();
        }
        if (timer != null) {
            timer.stop();
        }
        // Stop the background music
        if (backgroundMusic != null) {
            backgroundMusic.stop();
        }
        if (victorySound != null) {
            victorySound.play();
        }
        if (winSound != null) {
            winSound.play();
        }

        int totalCarrots = sumCarrotsCollected;
        int totalTime = view.getElapsedTime();

        //create JFrame
        JFrame winFrame = new JFrame("You win!");
        // Load background image
        ImageIcon originalIcon = new ImageIcon("java-project-2025-julie-bui/data/messagePopup2.jpg");
        Image scaledImage = originalIcon.getImage().getScaledInstance(550, 470, Image.SCALE_SMOOTH);
        ImageIcon bgIcon = new ImageIcon(scaledImage);
        JLabel background = new JLabel(bgIcon);
        background.setLayout(new BorderLayout());
        winFrame.setContentPane(background);
        //create label with text

        JLabel winLabel = new JLabel(
                "<html>" +
                        "Congratulations, you win!<br>" +
                        "Total carrots collected: " + totalCarrots + "<br>" +
                        "Total time: " + totalTime + " seconds" +
                        "</html>",
                SwingConstants.CENTER
        );
        winLabel.setFont(new Font("Monospaced", Font.BOLD, 20));

        //add label to jframe, set size, position
        winFrame.add(winLabel);
        winFrame.setSize(420, 380);
        winFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        winFrame.setLocation(180,250);
        winFrame.setVisible(true);

    }


    //if user loses message popup display user has lost
    public void displayGameOver() {
        if (currentLevel != null) {
            currentLevel.stop();
        }
        if (timer != null) {
            timer.stop();
        }

        int totalCarrots = sumCarrotsCollected;
        int totalTime = view.getElapsedTime();

        // Create a JFrame to display the game over message);
        JFrame gameOverFrame = new JFrame("Game Over!");
        // Load background image
        ImageIcon originalIcon = new ImageIcon("java-project-2025-julie-bui/data/messagePopup2.jpg");
        Image scaledImage = originalIcon.getImage().getScaledInstance(550, 470, Image.SCALE_SMOOTH);
        ImageIcon bgIcon = new ImageIcon(scaledImage);
        JLabel background = new JLabel(bgIcon);
        background.setLayout(new BorderLayout());
        gameOverFrame.setContentPane(background);
        gameOverFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gameOverFrame.setSize(420, 380);

        // Create a JLabel to display the message
        JLabel messageLabel = new JLabel(
                "<html>" +
                        "Game over, you lose!<br>" +
                        "Total carrots collected: " + totalCarrots + "<br>" +
                        "Total time: " + totalTime + " seconds" +
                        "</html>",
                JLabel.CENTER
        );
        messageLabel.setFont(new Font("Arial", Font.BOLD, 24));

        // Add the message to the frame
        gameOverFrame.add(messageLabel);

        // Center the window on the screen
        gameOverFrame.setLocation(180,250);

        // Make the window visible
        gameOverFrame.setVisible(true);
    }

    /**
     * saves current game progress to file
     * saves the current level, time and carrots collected to file
     */
    public void saveGame() {
        JLabel saveMessage = new JLabel(
                "<html>" +
                        "Progress saved<br>" +
                        "Successfully!" +
                        "</html>",
                JLabel.CENTER
        );
        saveMessage.setFont(new Font("Monospaced", Font.BOLD, 20));  // optional: make it match style
        saveMessage.setForeground(Color.BLACK); // optional: make sure text is visible

        // Create a JFrame for the save game message
        JFrame saveFrame = new JFrame("Game Saved");

        // Load background image
        ImageIcon originalIcon = new ImageIcon("java-project-2025-julie-bui/data/messagePopup2.jpg");
        Image scaledImage = originalIcon.getImage().getScaledInstance(550, 470, Image.SCALE_SMOOTH);
        ImageIcon bgIcon = new ImageIcon(scaledImage);
        JLabel background = new JLabel(bgIcon);
        background.setLayout(new BorderLayout());
        saveFrame.setContentPane(background);

        // Add the save message onto the background
        background.add(saveMessage, BorderLayout.CENTER);

        saveFrame.setSize(420, 380);
        saveFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        saveFrame.setLocation(180, 250);
        saveFrame.setVisible(true);
        GameStateWriter writer = new GameStateWriter("savegame.txt");
        try {
            writer.writeGameState(currentLevel.getName(), sumCarrotsCollected, view.getElapsedTime());
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to Save Game!", "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private GameLevel loadLevelByName(String name) {
        if (name.equals("Level 1")) return new LevelOne();
        else if (name.equals("Level 2")) return new LevelTwo();
        else if (name.equals("Level 3")) return new LevelThree();
        else return new LevelOne();
    }


    // Add a method to handle transitioning to the next level
    public void transitionToNextLevel() {
        // If Level 1 is complete, go to Level 2
        if (currentLevel instanceof LevelOne) {
            goToLevelTwo();
        }
        // If Level 2 is complete, go to Level 3
        else if (currentLevel instanceof LevelTwo) {
            goToLevelThree();
        }
        // If Level 3 is complete, display win message
        else if (currentLevel instanceof LevelThree) {
            displayWinMessage();
        }
    }

    /** Run the game.
     * */
    public static void main(String[] args) {
        new Game();
    }
}