package game;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Writes the game state (level name, carrots collected, elapsed time) to a text file.
 */
public class GameStateWriter {
    private String fileName;
    /**
     * initialises file name
     * @param fileName name of file of save game
     */
    public GameStateWriter(String fileName) {
        this.fileName = fileName;
    }

    /**
     * writes current game state to file to save
     * @param levelName current level name
     * @param sumCarrotsCollected total carrots
     * @param elapsedTime time when saved game
     * @throws IOException error occurs while writing to file
     */
    public void writeGameState(String levelName, int sumCarrotsCollected, int elapsedTime) throws IOException {
        boolean append = false; // Overwrite each time
        FileWriter writer = null; //file writer to write to file
        try {
            writer = new FileWriter(fileName, append); //open file in overwrite
            //write to file as CSV line
            writer.write(levelName + "," + sumCarrotsCollected + "," + elapsedTime + "\n");
        } finally {
            //close writer
            if (writer != null) {
                writer.close();
            }
        }
    }
}
