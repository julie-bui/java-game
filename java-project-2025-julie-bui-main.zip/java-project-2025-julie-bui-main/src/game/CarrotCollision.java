package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

//class deals with collisions between player and carrot
public class CarrotCollision implements CollisionListener {
    //reference to player, game
    private Player player;
    private Game game;

    /**
     * @param player The player object that's involved in collision detection
     * @param game The game object that updates when there's collisions
     */
    //constructor initialise collision listener with player, game reference
    public CarrotCollision(Player player, Game game) {
        //assign player, game object
        this.player = player;
        this.game = game;
    }

    /**
     *
     * @param e checks if player collides with carrot if so remove carrot from world
     *          increments carrot count
     */
    //method called when there's a collision
    @Override
    public void collide(CollisionEvent e) {
        //checks if colliding body is carrot and if reporting body player
        if (e.getOtherBody() instanceof Carrot && e.getReportingBody() == player) {
            player.incrementCarrots(); //  Increase carrot count
            e.getOtherBody().destroy(); //  Remove the carrot from the world
            game.carrotCollected();      // Notify game a carrot's collected
        }
    }
}