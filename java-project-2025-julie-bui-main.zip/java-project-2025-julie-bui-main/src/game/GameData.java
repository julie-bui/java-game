package game;

import java.io.Serializable;

public class GameData implements Serializable {
    private static final long serialVersionUID = 1L;

    public String levelName;
    public int sumCarrotsCollected;
    public int elapsedTime;

    public GameData(String levelName, int sumCarrotsCollected, int elapsedTime) {
        this.levelName = levelName;
        this.sumCarrotsCollected = sumCarrotsCollected;
        this.elapsedTime = elapsedTime;
    }
}
