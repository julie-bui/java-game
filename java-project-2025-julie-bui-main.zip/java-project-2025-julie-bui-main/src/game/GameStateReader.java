package game;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * Reads the saved game state from a text file.
 */
public class GameStateReader {
    private String fileName;

    /**
     * initialises file name
     * @param fileName name of file of save game
     */
    public GameStateReader(String fileName) {
        this.fileName = fileName;
    }

    /**
     * reads saved game state from file
     * takes level name, num of carrots and time
     * @return gamedate object containing saved state or null if file empty
     * @throws IOException if error occurs while reading file
     */
    public GameData readGameState() throws IOException {
        FileReader fr = null;
        BufferedReader reader = null;
        try {
            fr = new FileReader(fileName); //open file
            reader = new BufferedReader(fr); //initialise buffer reader
            String line = reader.readLine();
            if (line != null) {
                //split line into tokens - level, carrots, time
                String[] tokens = line.split(",");
                String levelName = tokens[0]; //extract level name
                int sumCarrotsCollected = Integer.parseInt(tokens[1]);
                int elapsedTime = Integer.parseInt(tokens[2]);
                //return parsed data as gamedata object
                return new GameData(levelName, sumCarrotsCollected, elapsedTime);
            }
        } finally {
            //close
            if (reader != null) reader.close();
            if (fr != null) fr.close();
        }
        //if file empty
        return null;
    }
}
