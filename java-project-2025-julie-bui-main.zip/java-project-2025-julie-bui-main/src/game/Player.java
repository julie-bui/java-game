package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Player extends Walker implements StepListener{
    //reference to game object
    private Game game;
    //static shape for player
    private static final Shape bunnyShape = new BoxShape(1, 2);

    //define images for player when facing right/left
    private static final BodyImage rightImage = new BodyImage("java-project-2025-julie-bui/data/bunnyRight.gif", 4);
    private static final BodyImage leftImage = new BodyImage("java-project-2025-julie-bui/data/bunnyLeft.gif", 4);
    //stores current image
    private AttachedImage currentImage;
    //player starts right, tracks direction
    private boolean facingRight = true;
    //tracks carrots collected
    private int carrots = 0;

    //constructor to initialise player object
    public Player(World world) {
        super(world, bunnyShape);
        //sets image facing right
        currentImage = new AttachedImage(this, rightImage, 1, 0, new Vec2(0, 0));
        world.addStepListener(this);
    }

    //updates player's direction
    public void setDirection(boolean movingRight) {
        //check if player facing right, if so no update needed
        if (movingRight == facingRight) {
            return;
        }
        facingRight = movingRight; //update direction

        //remove the current image before adding the new one
        if (currentImage != null) {
            this.removeAttachedImage(currentImage);
        }

        //add new image based on direction
        currentImage = new AttachedImage(this, facingRight ? rightImage : leftImage, 1, 0, new Vec2(0, 0));
    }

    //jump method
    public void jump() {
        //apply upward velocity to stimulate jumping
        this.setLinearVelocity(new Vec2(this.getLinearVelocity().x, 10));  // Apply upward velocity
    }
    // Method to check if the player is on the ground
    public boolean isOnGround() {
        // Check if the player's Y position is close to the ground in this case if Y is less than or equal to -9
        return this.getPosition().y <= -9; // Return true if the player is at or below Y = -9 (ground level)
    }

    // Method to move left
    public void moveLeft() {
        // Set the horizontal velocity to move the player to the left with speed 10 (keep the Y velocity the same)
        this.setLinearVelocity(new Vec2(-10, this.getLinearVelocity().y));  // Move left with speed 10
        setDirection(false);  // Update the direction to left (so the player faces left)
    }

    // Method to move right
    public void moveRight() {
        // Set the horizontal velocity to move the player to the right with speed 10 (keep the Y velocity the same)
        this.setLinearVelocity(new Vec2(10, this.getLinearVelocity().y));  // Move right with speed 10
        setDirection(true);  // Update direction to right
    }

    // Method to stop moving left
    public void stopMovingLeft() {
        // Set horizontal velocity to 0, keeping vertical velocity the same
        this.setLinearVelocity(new Vec2(0, this.getLinearVelocity().y));  // Stop horizontal movement
    }

    // Method to stop moving right
    public void stopMovingRight() {
        // Set horizontal velocity to 0, keeping vertical velocity the same
        this.setLinearVelocity(new Vec2(0, this.getLinearVelocity().y));  // Stop horizontal movement
    }

    // Method to move the player down (negative vertical velocity)
    public void movePlayerDown(){
        // Apply downward velocity to simulate moving down
        this.setLinearVelocity(new Vec2(this.getLinearVelocity().x, -10));
    }

    //method to increase carrots
    public void incrementCarrots() {
        carrots++;
    }
    //method to get number of carrots and return
    public int getCarrots(){
        return carrots;
    }

    // method to set the number of carrots
    public void setCarrots(int carrots) {
        this.carrots = carrots;
    }

    @Override
    public void preStep(StepEvent e) {
        // Get current position
        float x = this.getPosition().x;
        float y = this.getPosition().y;

        // Define screen boundaries
        float leftBound = -19;  // depends on your game width
        float rightBound = 19;
        float bottomBound = -20;
        float topBound = 14;

        // Clamp x within boundaries
        if (x < leftBound) {
            this.setPosition(new Vec2(leftBound, y));
        } else if (x > rightBound) {
            this.setPosition(new Vec2(rightBound, y));
        }

        // Optional: Clamp y too if you want top/bottom bounds
        if (y < bottomBound) {
            this.setPosition(new Vec2(x, bottomBound));
        } else if (y > topBound) {
            this.setPosition(new Vec2(x, topBound));
        }
    }

    @Override
    public void postStep(StepEvent e) {
        // You can leave this empty
    }

}


